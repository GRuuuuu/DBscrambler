Changes
=======

0.3.0 (2013-05-14)
------------------

- Fixed Python 3 support
- Improved tests and fixed minor bugs


0.2 (2013-02-17)
----------------

- Initial release
